# آرکیٹیکچر گائیڈ: HTML/JS سے Flutter + Backend

## کیوں یہ تبدیلی ضروری تھی

پرانا ٹول ایک single-file HTML تھا جو براؤزر کے Canvas API اور JavaScript پر
مکمل انحصار کرتا تھا۔ یہ چھوٹے کاموں کے لیے ٹھیک تھا مگر:

- بڑی تصاویر (جیسے 20+ اسکین شدہ گرڈ خانے) پر Canvas سست پڑ جاتا اور UI جم جاتی
- براؤزر کی میموری محدود ہے، بڑی ZIP فائلیں بناتے وقت crash کا خطرہ
- AI فیچرز (background removal) کلائنٹ پر چلانا بہت سست اور بھاری تھا
- کوئی offline/native ایپ کا تجربہ نہیں تھا (ہر بار براؤزر کھولنا پڑتا)

## نیا نظام: دو حصے

### 1. فرنٹ اینڈ (Flutter) — تیز، مقامی کام
موبائل پر خود چلتا ہے، انٹرنیٹ کے بغیر بھی کام کرتا ہے:

| کام | پرانا طریقہ | نیا طریقہ |
|---|---|---|
| Crop/Resize | JS Canvas (main thread) | `image` package، الگ isolate میں |
| گرڈ کاٹنا | Canvas pixel manipulation | `img.copyCrop` (native، تیز) |
| ZIP بنانا | JSZip (JavaScript) | `archive` package (Dart، native) |
| PDF بنانا | نہیں تھا | `pdf` + `printing` packages |
| کیمرہ | ویب کیمرہ API | `camera` + `image_picker` (native) |

**فائدہ:** isolate کا استعمال یعنی بھاری پروسیسنگ الگ تھریڈ میں چلتی ہے،
UI کبھی freeze نہیں ہوتی — 20-30 تصاویر بھی ایک ساتھ پروسیس ہو سکتی ہیں۔

### 2. بیک اینڈ (Python/FastAPI پر Cloud Run) — بھاری AI کام
صرف اس کام کے لیے استعمال ہوتا ہے جو موبائل پر مقامی طور پر کرنا ناقابلِ عمل ہے:

| کام | کیوں سرور پر |
|---|---|
| Background Removal (rembg/U2Net) | AI ماڈل بھاری ہے (~170MB)، موبائل پر سست اور بیٹری خرچ |

باقی سب کچھ (crop, resize, grid split, ZIP export) **مقامی طور پر Flutter میں** ہوتا ہے —
اس لیے انٹرنیٹ کی ضرورت صرف background removal کے وقت پڑتی ہے۔

## ڈیٹا کا بہاؤ (Flow)

```
[صارف] → تصویر لیتا/اپلوڈ کرتا ہے
   ↓
[Flutter App - مقامی]
   ├─ Crop + Resize + Compress (isolate میں)
   ├─ اگر background removal درکار ہو →
   │      [HTTP POST] → [Cloud Run Backend] → پروسیس شدہ تصویر واپس
   ↓
[ZIP/PDF بنانا - مقامی]
   ↓
[صارف کو شیئر/ڈاؤن لوڈ]
```

## کیا replace کرنا ضروری ہے (پرفارمنس کے لیے)

1. **Canvas → `image` package + `compute()` isolates**
   سب سے بڑی تبدیلی۔ UI thread پر بھاری کام کبھی نہ کریں۔

2. **JSZip → `archive` package**
   Dart native، براؤزر میموری کی حد نہیں۔

3. **localStorage/sessionStorage → `sqflite` (SQLite)**
   اگر طلبہ کا ریکارڈ رکھنا ہو تو مقامی ڈیٹا بیس استعمال کریں،
   نہ کہ براؤزر سٹوریج (جو ایپ میں سرے سے موجود ہی نہیں)۔

4. **AI ماڈل (RMBG-1.4 in browser) → Server-side rembg**
   موبائل پر بھاری ماڈل چلانا بیٹری اور وقت دونوں ضائع کرتا ہے۔
   سرور پر ایک بار لوڈ ہو کر تیزی سے کئی requests پروسیس کر سکتا ہے۔

## اگلے اختیاری قدم

- **Firebase Authentication** شامل کریں اگر مختلف سکولوں/صارفین کی تصاویر الگ رکھنی ہوں
- **Cloud Storage bucket** شامل کریں اگر تصاویر سرور پر محفوظ رکھنی ہوں (بجائے صرف موبائل پر)
- **SIS پورٹل API** کے ساتھ integration — طالب علم کا ڈیٹا خودکار fetch کر کے
  فائل کے نام میں GR Number استعمال کیا جا سکتا ہے (آپ کے دوسرے پروجیکٹ سے جوڑا جا سکتا ہے)
