package com.example.multi_image_crop_and_resizer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}