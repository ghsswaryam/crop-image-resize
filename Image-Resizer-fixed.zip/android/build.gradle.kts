// یہ فائل android/build.gradle.kts ہے
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

// 🛠️ یہاں سٹرنگ کو فائل آبجیکٹ میں تبدیل کر دیا گیا ہے
rootProject.layout.buildDirectory.set(file("../build"))

subprojects {
    project.layout.buildDirectory.set(file("${rootProject.layout.buildDirectory.get().asFile}/${project.name}"))
}

subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
