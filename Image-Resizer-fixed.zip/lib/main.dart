import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // 👈 یہاں سیمی کولن (;) لگا دیا گیا ہے

// 🌟 درست پاتھس کے ساتھ امپورٹس
import 'services/image_service.dart';
import 'screens/home_screen.dart';

void main() {
  // 🌟 فلٹر بائنڈنگز کو یقینی بنائیں
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // 🌟 ChangeNotifierProvider: پوری ایپ کے لیے اسٹیٹ مینجمنٹ (زبان اور ڈیٹا)
    return ChangeNotifierProvider(
      create: (_) => ImageService(),
      child: MaterialApp(
        title: 'Multi Image Tool',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          primaryColor: const Color(0xFF006064),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF006064),
            primary: const Color(0xFF006064),
          ),
          // 🌟 ایپ کا ڈیفالٹ فونٹ جو اردو کے لیے بہترین ہے
          fontFamily: 'NotoNastaliqUrdu', 
        ),
        // 🌟 ہوم سکرین سے شروعات
        home: const HomeScreen(),
      ),
    );
  }
}