import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/image_service.dart';
import '../utils/app_strings.dart'; 

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ImageService>(
      builder: (context, service, child) {
        final isUrdu = service.isUrdu;
        final urduStyle = TextStyle(fontFamily: isUrdu ? 'NotoNastaliqUrdu' : null);

        return Directionality(
          textDirection: isUrdu ? TextDirection.rtl : TextDirection.ltr,
          child: Drawer(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                DrawerHeader(
                  decoration: const BoxDecoration(color: Color(0xFF006064)),
                  child: Center(
                    child: Text(
                      AppStrings.text('appName', isUrdu), // 🛠️ فکس: ایپ کا نام
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.home),
                  title: Text(AppStrings.text('home', isUrdu), style: urduStyle), // 🛠️ فکس: ہوم
                  onTap: () {
                    Navigator.pop(context);
                    // ہوم پر جانے کا منطقی طریقہ
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.language),
                  title: Text(AppStrings.text('language', isUrdu), style: urduStyle), // 🛠️ فکس: زبان
                  onTap: () {
                    service.toggleLanguage();
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
