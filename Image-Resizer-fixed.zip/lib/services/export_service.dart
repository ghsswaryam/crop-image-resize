// lib/services/export_service.dart
import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:archive/archive_io.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import '../models/photo_item.dart';
import '../models/export_options.dart';

class ExportService {
  
  /// 1. تصاویر کو کسٹم فولڈر میں مطلوبہ فارمیٹ، کوالٹی اور آٹو نمبرنگ کے ساتھ محفوظ کرنا
  static Future<List<File>> exportImages(List<PhotoItem> photos, ExportOptions options) async {
    List<File> exportedFiles = [];
    int currentIndex = options.startNumber;

    for (var photo in photos) {
      final sourcePath = photo.processedPath ?? photo.imagePath;
      final sourceFile = File(sourcePath);
      
      if (!await sourceFile.exists()) continue;

      // فائل کا ایکسٹینشن طے کرنا
      String extension = _getExtensionString(options.format);
      if (options.format == ExportFormat.original) {
        extension = p.extension(sourcePath).replaceAll('.', '');
      }

      // 🌟 فائل کا نام تیار کرنا: اگر اس مخصوص تصویر کے لیے صارف نے پہلے
      // ہی نام لکھا ہے (photo.customName) تو وہی استعمال ہو گا — ورنہ
      // مشترکہ Base File Name + سیریل نمبر (مثلاً: Student_Image_001.jpg)
      final String? typedName = photo.customName?.trim();
      String fileName;
      if (typedName != null && typedName.isNotEmpty) {
        fileName = '$typedName.$extension';
      } else {
        String base = options.baseName.isNotEmpty ? options.baseName : 'Image';
        if (options.autoNumber) {
          String paddedNum = currentIndex.toString().padLeft(3, '0');
          fileName = '${base}_$paddedNum.$extension';
        } else {
          fileName = '$base.$extension';
        }
      }

      String targetFilePath = p.join(options.destinationPath, fileName);

      // ڈوپلیکیٹ فائل ہینڈلنگ (اگر اوور رائٹ کی اجازت نہ ہو)
      if (await File(targetFilePath).exists() && !options.overwriteExisting) {
        int duplicateIndex = 1;
        while (await File(targetFilePath).exists()) {
          String nameWithoutExt = p.basenameWithoutExtension(fileName);
          targetFilePath = p.join(options.destinationPath, '${nameWithoutExt}_$duplicateIndex.$extension');
          duplicateIndex++;
        }
      }

      // اصلی تصویر کو انکوڈ اور سیو کرنا
      File finalFile = await _processAndSaveFormat(sourceFile, targetFilePath, options);
      exportedFiles.add(finalFile);
      
      currentIndex++;
    }

    return exportedFiles;
  }

  /// 2. تمام تصاویر کی ZIP فائل تیار کرنا (پروگریس اور کینسل کے ساتھ)
  static Future<File> createZipWithProgress({
    required List<PhotoItem> photos,
    required ExportOptions options,
    required bool Function() checkCancel,
    required Function(double) onProgress,
  }) async {
    List<File> exportedFiles = await exportImages(photos, options);

    final encoder = ZipFileEncoder();
    
    String zipName = options.zipFileName?.isNotEmpty == true 
        ? '${options.zipFileName}.zip' 
        : 'Admissions_Export_${DateTime.now().millisecondsSinceEpoch}.zip';
    
    String zipPath = p.join(options.destinationPath, zipName);
    encoder.create(zipPath);

    int totalFiles = exportedFiles.length;
    for (int i = 0; i < totalFiles; i++) {
      if (checkCancel()) {
        encoder.close();
        throw Exception('Processing cancelled by user.');
      }

      final file = exportedFiles[i];
      encoder.addFile(file);

      onProgress((i + 1) / totalFiles);
      await Future.delayed(const Duration(milliseconds: 10));
    }

    encoder.close();
    return File(zipPath);
  }

  /// 3. فائل شیئرنگ کے لیے
  static Future<void> shareFile(File file) async {
    if (await file.exists()) {
      await Share.shareXFiles([XFile(file.path)], text: 'ملٹی امیج کراپ ریسائز اینڈ رینیم سے برآمد کردہ فائل');
    }
  }

  // ==========================================
  // HELPER METHODS
  // ==========================================

  static String _getExtensionString(ExportFormat format) {
    switch (format) {
      case ExportFormat.jpg: return 'jpg';
      case ExportFormat.png: return 'png';
      case ExportFormat.webp: return 'webp';
      case ExportFormat.bmp: return 'bmp';
      case ExportFormat.tiff: return 'tiff';
      case ExportFormat.original: return 'jpg';
    }
  }

  static Future<File> _processAndSaveFormat(File sourceFile, String targetPath, ExportOptions options) async {
    if (options.format == ExportFormat.original) {
      return await sourceFile.copy(targetPath);
    }

    final bytes = await sourceFile.readAsBytes();
    final img.Image? decodedImage = img.decodeImage(bytes);

    if (decodedImage == null) {
      return await sourceFile.copy(targetPath);
    }

    List<int> encodedBytes;
    
    // 🌟 فارمیٹ اور کوالٹی کی جانچ (صرف JPG اور WebP پر کوالٹی لاگو ہوگی)
    switch (options.format) {
      case ExportFormat.png:
        encodedBytes = img.encodePng(decodedImage);
        break;
      case ExportFormat.webp:
        encodedBytes = img.encodeNamedImage(targetPath, decodedImage) ?? img.encodeJpg(decodedImage, quality: options.quality);
        break;
      case ExportFormat.bmp:
        encodedBytes = img.encodeBmp(decodedImage);
        break;
      case ExportFormat.tiff:
        // اگر tiff فارمیٹ ہو تو اسے درست طریقے سے ہینڈل کرنا یا فال بیک دینا
        encodedBytes = img.encodeJpg(decodedImage, quality: options.quality);
        break;
      case ExportFormat.jpg:
      case ExportFormat.original:
        encodedBytes = img.encodeJpg(decodedImage, quality: options.quality);
        break;
    }

    final targetFile = File(targetPath);
    await targetFile.writeAsBytes(encodedBytes);
    return targetFile;
  }
}
