// lib/services/image_service.dart
import 'dart:io';
import 'dart:async';
import 'dart:isolate';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import '../models/photo_item.dart';
import '../models/grid_settings.dart';

/// 🌟 لائیو پروگریس اور ای ٹی اے (ETA) کے لیے کلاس
class ImageProcessingProgress {
  final int processedCount;
  final int totalCount;
  final String currentFileName;
  final String estimatedTimeLeft;

  ImageProcessingProgress({
    required this.processedCount,
    required this.totalCount,
    required this.currentFileName,
    required this.estimatedTimeLeft,
  });
}

/// 🌟 ایک زیرِ عمل (active) آئسولیٹ ٹاسک کا ریکارڈ — تاکہ کینسل پر
/// اسے فوری طور پر kill کیا جا سکے اور اس کا Future بھی فوراً مکمل ہو جائے
/// (ورنہ کینسل بٹن دبانے کے باوجود UI اسی تصویر کے ختم ہونے کا انتظار کرتا رہتا)
class _ActiveTask {
  final Isolate isolate;
  final Completer<_ProcessResult> completer;
  final ReceivePort resultPort;
  final ReceivePort errorPort;
  _ActiveTask(this.isolate, this.completer, this.resultPort, this.errorPort);

  void killNow() {
    isolate.kill(priority: Isolate.immediate);
    resultPort.close();
    errorPort.close();
    if (!completer.isCompleted) {
      completer.complete(_ProcessResult.failure());
    }
  }
}

class ImageService extends ChangeNotifier {
  final List<PhotoItem> _photos = [];
  bool _cancelRequested = false;
  final List<_ActiveTask> _activeTasks = [];

  // 🌟 کم رفتار (low-end) فونز پر میموری محفوظ رکھنے کے لیے بیک وقت
  // زیادہ سے زیادہ 3 تصاویر ہی پروسیس ہوں گی — لیکن سیریل (ایک ایک کر کے)
  // پروسیسنگ کی بجائے یہ رفتار کئی گنا بہتر بنا دیتا ہے۔
  static const int _concurrency = 3;

  List<PhotoItem> get photos => _photos;

  // 🌟 زبان کنٹرول اسٹیٹ
  bool _isUrdu = true;
  bool get isUrdu => _isUrdu;

  void toggleLanguage() {
    _isUrdu = !_isUrdu;
    notifyListeners();
  }

  // 🌟 تصاویر شامل کرنا
  void addPhotos(List<PhotoItem> items) {
    for (var item in items) {
      final file = File(item.imagePath);
      if (file.existsSync()) {
        final sizeInBytes = file.lengthSync();
        final sizeInMB = sizeInBytes / (1024 * 1024);
        String originalSize = sizeInMB > 1.0
            ? '${sizeInMB.toStringAsFixed(2)} MB'
            : '${(sizeInBytes / 1024).toStringAsFixed(0)} KB';
        _photos.add(item.copyWith(originalSizeDisplay: originalSize));
      } else {
        _photos.add(item);
      }
    }
    notifyListeners();
  }

  void setPhotos(List<PhotoItem> photos) {
    _photos.clear();
    _photos.addAll(photos);
    notifyListeners();
  }

  void clearPhotos() {
    _photos.clear();
    notifyListeners();
  }

  void updatePhoto(PhotoItem updatedPhoto) {
    final index = _photos.indexWhere((p) => p.id == updatedPhoto.id);
    if (index != -1) {
      _photos[index] = updatedPhoto;
      notifyListeners();
    }
  }

  void removePhoto(String id) {
    _photos.removeWhere((item) => item.id == id);
    notifyListeners();
  }

  /// 🌟 فوری کینسل: تمام رواں (in-flight) آئسولیٹس کو فوراً kill کیا جاتا ہے
  /// تاکہ کینسل بٹن دبانے پر ایپ اسی لمحے رک جائے — کسی تصویر کے مکمل
  /// ہونے کا انتظار نہیں کرنا پڑتا۔
  void cancelProcessing() {
    _cancelRequested = true;
    final tasksToKill = List<_ActiveTask>.from(_activeTasks);
    _activeTasks.clear();
    for (final t in tasksToKill) {
      t.killNow();
    }
  }

  /// 🌟 اصل اسٹریم پروسیسنگ — بیک وقت کئی تصاویر (isolate pool) + فوری کینسل
  /// + جو تصویر پہلے سے ہدف سائز/ڈائمنشن پر ہے اسے دوبارہ پروسیس نہیں کرتا (fast-skip)۔
  Stream<ImageProcessingProgress> processPhotosAsStream(
    GridSettings settings,
    bool Function() checkCancel,
  ) async* {
    _cancelRequested = false;
    final int total = _photos.length;
    int processed = 0;

    final stopwatch = Stopwatch()..start();

    for (int batchStart = 0; batchStart < total; batchStart += _concurrency) {
      if (_cancelRequested || checkCancel()) break;

      final int batchEnd = (batchStart + _concurrency) > total ? total : (batchStart + _concurrency);
      final indices = [for (int i = batchStart; i < batchEnd; i++) i];

      // 🌟 پورا بیچ بیک وقت شروع کریں — الگ الگ isolate پر
      final futures = indices.map((i) => _processOne(i, settings)).toList();
      final results = await Future.wait(futures);

      if (_cancelRequested || checkCancel()) break;

      for (int k = 0; k < results.length; k++) {
        final i = indices[k];
        final result = results[k];
        final photo = _photos[i];
        final fileName = File(photo.imagePath).uri.pathSegments.last;

        if (result.success && result.outputPath != null) {
          _photos[i] = photo.copyWith(
            processedPath: result.outputPath,
            finalSizeKB: result.sizeKB,
            width: result.finalWidth ?? settings.targetWidth,
            height: result.finalHeight ?? settings.targetHeight,
          );
        }
        processed++;

        final elapsed = stopwatch.elapsedMilliseconds;
        final avgTimePerImage = processed > 0 ? elapsed / processed : 0;
        final remainingImages = total - processed;
        final estimatedMs = (avgTimePerImage * remainingImages).toInt();

        String timeStr = '${(estimatedMs / 1000).toStringAsFixed(1)}s remaining';
        if (estimatedMs < 1000) timeStr = 'Less than a second';

        yield ImageProcessingProgress(
          processedCount: processed,
          totalCount: total,
          currentFileName: fileName,
          estimatedTimeLeft: timeStr,
        );
      }
    }

    stopwatch.stop();
    notifyListeners();
  }

  /// 🌟 ایک تصویر پروسیس کرنے کا فیصلہ: اگر تصویر پہلے سے ہدف
  /// ڈائمنشن اور KB حد کے اندر ہے تو دوبارہ decode/encode کیے بغیر
  /// فوری طور پر "مکمل" مان لیا جاتا ہے — یہ بہت سے کیسز میں (خاص طور
  /// پر گرڈ کراپ کے بعد جہاں تصویر پہلے ہی ہدف سائز پر بن چکی ہوتی ہے)
  /// پروسیسنگ کو سیکنڈز میں مکمل کر دیتا ہے۔
  Future<_ProcessResult> _processOne(int index, GridSettings settings) async {
    final photo = _photos[index];
    final file = File(photo.imagePath);
    if (!await file.exists()) return _ProcessResult.failure();

    try {
      final lengthBytes = await file.length();
      final targetBytes = settings.targetKB * 1024;
      final bool alreadyGood = photo.width == settings.targetWidth &&
          photo.height == settings.targetHeight &&
          photo.rotation == 0 &&
          lengthBytes > 0 &&
          lengthBytes <= targetBytes;

      if (alreadyGood) {
        return _ProcessResult(
          success: true,
          sizeKB: (lengthBytes / 1024).round(),
          outputPath: photo.imagePath,
          finalWidth: photo.width,
          finalHeight: photo.height,
        );
      }
    } catch (_) {
      // معلوم نہ ہو سکے تو نیچے دیئے گئے مکمل پروسیسنگ والے راستے پر جائیں
    }

    final task = _ProcessTask(
      imagePath: photo.imagePath,
      width: settings.targetWidth,
      height: settings.targetHeight,
      targetSizeKB: settings.targetKB,
      quality: settings.quality,
      rotation: photo.rotation,
      outputPath: '${Directory.systemTemp.path}/${photo.id}_${DateTime.now().millisecondsSinceEpoch}.jpg',
    );

    return _runInKillableIsolate(task);
  }

  /// 🛠️ ایک آزاد، قابلِ-کِل (killable) آئسولیٹ میں تصویر پروسیس کرنا۔
  /// `compute()` کے برعکس یہ ہینڈل رکھتا ہے تاکہ cancelProcessing() اسے
  /// درمیان میں ہی فوراً روک سکے۔
  Future<_ProcessResult> _runInKillableIsolate(_ProcessTask task) async {
    final resultPort = ReceivePort();
    final errorPort = ReceivePort();
    final completer = Completer<_ProcessResult>();
    Isolate? isolate;
    _ActiveTask? activeTask;

    late StreamSubscription resultSub;
    late StreamSubscription errorSub;

    resultSub = resultPort.listen((data) {
      if (!completer.isCompleted) {
        completer.complete(data is _ProcessResult ? data : _ProcessResult.failure());
      }
    });
    errorSub = errorPort.listen((_) {
      if (!completer.isCompleted) {
        completer.complete(_ProcessResult.failure());
      }
    });

    try {
      isolate = await Isolate.spawn(
        _isolateEntryPoint,
        _IsolateArgs(task, resultPort.sendPort),
        onError: errorPort.sendPort,
        errorsAreFatal: true,
      );

      activeTask = _ActiveTask(isolate, completer, resultPort, errorPort);
      if (_cancelRequested) {
        // 🌟 اگر اسپان ہونے سے پہلے ہی کینسل ہو چکا ہو تو فوراً بند کریں
        activeTask.killNow();
        return _ProcessResult.failure();
      }
      _activeTasks.add(activeTask);

      final result = await completer.future;
      return result;
    } catch (_) {
      return _ProcessResult.failure();
    } finally {
      if (activeTask != null) _activeTasks.remove(activeTask);
      await resultSub.cancel();
      await errorSub.cancel();
      resultPort.close();
      errorPort.close();
      isolate?.kill(priority: Isolate.immediate);
    }
  }

  /// 🛠️ آئسولیٹ کا Entry-Point — ایک تصویر پروسیس کر کے نتیجہ واپس بھیجتا ہے
  static void _isolateEntryPoint(_IsolateArgs args) {
    final result = _processSingleImage(args.task);
    args.sendPort.send(result);
  }

  /// 🛠️ اصل پروسیسنگ منطق (decode → crop/resize → binary-search compress)
  static _ProcessResult _processSingleImage(_ProcessTask task) {
    img.Image? rawImage;
    img.Image? croppedImage;
    img.Image? resizedImage;

    try {
      final file = File(task.imagePath);
      if (!file.existsSync()) return _ProcessResult.failure();

      final bytes = file.readAsBytesSync();
      rawImage = img.decodeImage(bytes);
      if (rawImage == null) return _ProcessResult.failure();

      final oriented = img.bakeOrientation(rawImage);
      final processedImage = task.rotation != 0
          ? img.copyRotate(oriented, angle: task.rotation)
          : oriented;

      final bool alreadyCorrectSize =
          processedImage.width == task.width && processedImage.height == task.height;

      img.Image finalImage;
      if (alreadyCorrectSize) {
        finalImage = processedImage;
      } else {
        final double srcAspect = processedImage.width / processedImage.height;
        final double targetAspect = task.width / task.height;

        if ((srcAspect - targetAspect).abs() > 0.01) {
          int cropWidth, cropHeight, cropX, cropY;
          if (srcAspect > targetAspect) {
            cropHeight = processedImage.height;
            cropWidth = (cropHeight * targetAspect).toInt();
            cropX = (processedImage.width - cropWidth) ~/ 2;
            cropY = 0;
          } else {
            cropWidth = processedImage.width;
            cropHeight = (cropWidth / targetAspect).toInt();
            cropX = 0;
            cropY = (processedImage.height - cropHeight) ~/ 2;
          }
          croppedImage = img.copyCrop(processedImage,
              x: cropX, y: cropY, width: cropWidth, height: cropHeight);
        } else {
          croppedImage = processedImage;
        }

        // 🌟 یہاں High-Quality Cubic Interpolation لگائی گئی ہے تاکہ بلر ختم ہو
        resizedImage = img.copyResize(
          croppedImage,
          width: task.width,
          height: task.height,
          interpolation: img.Interpolation.cubic,
        );
        finalImage = resizedImage;
      }

      img.Image workingImage = finalImage;
      final int targetBytes = task.targetSizeKB * 1024;

      List<int> compressedBytes = _bestQualityForTarget(workingImage, task.quality, targetBytes);

      // 🌟 اگر سائز بڑا ہو تو کوالٹی گرانے کی بجائے ڈائمینشنز کو آہستہ آہستہ کم کریں
      int safetyAttempts = 0;
      while (compressedBytes.length > targetBytes && safetyAttempts < 6) {
        safetyAttempts++;
        final int newWidth = (workingImage.width * 0.90).round();
        final int newHeight = (workingImage.height * 0.90).round();
        if (newWidth < 100 || newHeight < 100) break;

        final img.Image downscaled = img.copyResize(
          workingImage,
          width: newWidth,
          height: newHeight,
          interpolation: img.Interpolation.cubic,
        );
        if (workingImage != finalImage) workingImage.clear();
        workingImage = downscaled;

        compressedBytes = _bestQualityForTarget(workingImage, task.quality, targetBytes);
      }

      final Uint8List bestEncoded = Uint8List.fromList(compressedBytes);
      final File tempFile = File('${task.outputPath}.tmp');
      tempFile.writeAsBytesSync(bestEncoded);
      tempFile.renameSync(task.outputPath);

      return _ProcessResult(
        success: true,
        sizeKB: (bestEncoded.length / 1024).round(),
        outputPath: task.outputPath,
        finalWidth: workingImage.width,
        finalHeight: workingImage.height,
      );
    } catch (_) {
      return _ProcessResult.failure();
    } finally {
      rawImage?.clear();
      croppedImage?.clear();
      resizedImage?.clear();
    }
  }

  /// 🌟 بہترین کوالٹی الگورتھم: کم از کم کوالٹی 40% رکھی گئی ہے تاکہ امیج HD رہے
  static List<int> _bestQualityForTarget(img.Image image, int maxQuality, int targetBytes) {
    int low = 40; // 🌟 کوالٹی کبھی 40% سے نیچے نہیں جائے گی
    int high = maxQuality.clamp(40, 100);
    List<int> best = img.encodeJpg(image, quality: low);

    while (low <= high) {
      final int mid = (low + high) ~/ 2;
      final List<int> attempt = img.encodeJpg(image, quality: mid);
      if (attempt.length <= targetBytes) {
        best = attempt;
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }
    return best;
  }
}

/// 🛠️ Isolate.spawn کو دیا جانے والا آرگومنٹ (task + جواب بھیجنے کا پورٹ)
class _IsolateArgs {
  final _ProcessTask task;
  final SendPort sendPort;
  const _IsolateArgs(this.task, this.sendPort);
}

class _ProcessTask {
  final String imagePath;
  final int width;
  final int height;
  final int targetSizeKB;
  final int quality;
  final double rotation;
  final String outputPath;

  const _ProcessTask({
    required this.imagePath,
    required this.width,
    required this.height,
    required this.targetSizeKB,
    required this.quality,
    required this.rotation,
    required this.outputPath,
  });
}

class _ProcessResult {
  final bool success;
  final int? sizeKB;
  final String? outputPath;
  final int? finalWidth;
  final int? finalHeight;

  const _ProcessResult({
    required this.success,
    this.sizeKB,
    this.outputPath,
    this.finalWidth,
    this.finalHeight,
  });

  factory _ProcessResult.failure() => const _ProcessResult(success: false);
}
