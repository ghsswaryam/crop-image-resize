// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:provider/provider.dart';
import '../models/grid_settings.dart'; 
import '../services/image_service.dart';
import '../utils/app_strings.dart';
import '../widgets/app_drawer.dart'; // 🌟 آپ کا کسٹم دراز
import 'multi_upload_screen.dart'; 
import 'grid_crop_screen.dart';   

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key}); 

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  DateTime? currentBackPressTime;
  final AudioPlayer _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    
    // 🌟 ہر بار ایپ کھلنے پر درود شریف کا ڈائیلاگ دکھائیں
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _showWelcomeDaroodDialog(context);
      }
    });

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true); 

    _fadeAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  void _playClickSound() async {
    try {
      await _audioPlayer.stop();
      await _audioPlayer.play(AssetSource('click.mp3'));
    } catch (e) {
      debugPrint("آڈیو چلانے میں مسئلہ: $e");
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _showWelcomeDaroodDialog(BuildContext mainContext) {
    int welcomeCounter = 0; 
    bool showJazakallah = false; 
    
    // Provider سے موجودہ زبان معلوم کریں
    final service = mainContext.read<ImageService>();
    final isUrdu = service.isUrdu;
    final urduStyle = TextStyle(fontFamily: isUrdu ? 'NotoNastaliqUrdu' : null);

    showDialog(
      context: mainContext,
      barrierDismissible: false, 
      builder: (BuildContext dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return PopScope(
              canPop: false, 
              child: Dialog(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Directionality(
                  textDirection: TextDirection.rtl, 
                  child: Container(
                      width: MediaQuery.of(mainContext).size.width * 0.90,
                    padding: const EdgeInsets.all(20),
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 400),
                      child: showJazakallah 
                          ? SizedBox(
                              height: 150, 
                              child: Center(
                                child: Text(AppStrings.text('jazakallah', isUrdu), 
                                    style: urduStyle.copyWith(fontSize: 20, fontWeight: FontWeight.bold, color: const Color(0xFF2E7D32))),
                              ),
                            )
                          : Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(AppStrings.text('importantMessage', isUrdu), 
                                    style: urduStyle.copyWith(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.red)),
                                const SizedBox(height: 15),
                                Text(AppStrings.text('readDaroodPrompt', isUrdu), 
                                    style: urduStyle.copyWith(fontSize: 14), textAlign: TextAlign.center),
                                const SizedBox(height: 20),
                                Text(AppStrings.text('daroodText', isUrdu), 
                                    style: urduStyle.copyWith(fontSize: 18, fontWeight: FontWeight.w900, color: Colors.green), textAlign: TextAlign.center),
                                const SizedBox(height: 20),
                                Text('${AppStrings.text('readCount', isUrdu)} $welcomeCounter / 10', 
                                    style: urduStyle.copyWith(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.teal)),
                                const SizedBox(height: 20),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4CAF50), foregroundColor: Colors.white),
                                  onPressed: () {
                                    _playClickSound();
                                    setDialogState(() {
                                      if (welcomeCounter < 10) welcomeCounter++;
                                      if (welcomeCounter >= 10) {
                                        showJazakallah = true; 
                                        Future.delayed(const Duration(milliseconds: 1500), () => Navigator.pop(dialogContext));
                                      }
                                    });
                                  },
                                  child: Text(AppStrings.text('clickHereAfterDarood', isUrdu), style: urduStyle),
                                ),
                              ],
                            ),
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final service = context.watch<ImageService>();
    final isUrdu = service.isUrdu;
    final urduStyle = TextStyle(fontFamily: isUrdu ? 'NotoNastaliqUrdu' : null);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        DateTime now = DateTime.now();
        if (currentBackPressTime == null || now.difference(currentBackPressTime!) > const Duration(seconds: 2)) {
          currentBackPressTime = now;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                AppStrings.text('pressBackToExit', isUrdu),
                textAlign: TextAlign.center,
                style: urduStyle.copyWith(color: Colors.white, fontSize: 14),
              ),
              backgroundColor: Colors.black87,
              duration: const Duration(seconds: 2),
            ),
          );
        } else {
          SystemNavigator.pop(); 
        }
      },
      child: Directionality(
        textDirection: isUrdu ? TextDirection.rtl : TextDirection.ltr,
        child: Scaffold(
          backgroundColor: Colors.grey.shade50, 
          drawer: const AppDrawer(), // 🌟 کسٹم دراز کا استعمال
          appBar: PreferredSize(
  preferredSize: const Size.fromHeight(kToolbarHeight),
  child: Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        colors: [
          Color(0xFF004D40),
          Color(0xFF006064),
        ],
      ),
      boxShadow: [
        BoxShadow(
          color: Colors.black12,
          blurRadius: 10,
          offset: Offset(0, 4),
        ),
      ],
    ),
    child: AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      foregroundColor: Colors.white,
      title: Align(
        alignment:
            isUrdu ? Alignment.centerRight : Alignment.centerLeft,
        child: Text(
          AppStrings.text('appName', isUrdu),
          style: urduStyle.copyWith(
            fontSize: isUrdu ? 22 : 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      centerTitle: false,
    ),
  ),
),
          body: SafeArea(
            child: Column(
              children: [
                const Spacer(flex: 1),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24), 
                  child: Column(
                    children: [
                      Text(
                        AppStrings.text('selectWorkMode', isUrdu), 
                        style: urduStyle.copyWith(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.teal.shade900),
                      ),
                      const SizedBox(height: 32), 
                      
                      _ModeCard(
                        title: AppStrings.text('gridPageTitle', isUrdu), 
                        subtitle: AppStrings.text('gridPageSubtitle', isUrdu),
                        icon: Icons.grid_view_rounded, 
                        isUrdu: isUrdu,
                        onTap: () {
                          _playClickSound(); 
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const GridCropScreen(
                                initialSettings: GridSettings(rows: 5, cols: 4, targetWidth: 600, targetHeight: 800, targetKB: 23),
                          )));
                        },
                      ),
                      const SizedBox(height: 20), 
                      
                      _ModeCard(
                        title: AppStrings.text('uploadSeparateTitle', isUrdu), 
                        subtitle: AppStrings.text('uploadSeparateSubtitle', isUrdu),
                        icon: Icons.photo_library_rounded, 
                        isUrdu: isUrdu,
                        onTap: () {
                          _playClickSound(); 
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const MultiUploadScreen())); 
                        },
                      ),
                    ],
                  ),
                ),
                const Spacer(flex: 2),

                FadeTransition(
                  opacity: _fadeAnimation,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 25.0),
                    child: Column(
                      children: [
                        Container(
  padding: const EdgeInsets.symmetric(
    horizontal: 20,
    vertical: 10,
  ),
  decoration: BoxDecoration(
    color: const Color(0xFF006064).withValues(alpha: 0.05),
    borderRadius: BorderRadius.circular(30),
    border: Border.all(
      color: const Color(0xFF006064).withValues(alpha: 0.2),
      width: 1.5,
    ),
  ),
  child: const Text(
    "Developed By: Ghulam Shabbir (SSS-Geo)",
    style: TextStyle(
      fontSize: 12,
      fontWeight: FontWeight.bold,
      color: Color(0xFF004D40),
      letterSpacing: 0.6,
    ),
  ),
),
const SizedBox(height: 8),
Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [
    Icon(
      Icons.phone_android_rounded,
      size: 15,
      color: Colors.teal.shade800,
    ),
    const SizedBox(width: 6),
    const Text(
      "03157432791",
      style: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.bold,
        color: Colors.black87,
        letterSpacing: 1.2,
      ),
    ),
  ],
),
                            
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final bool isUrdu;

  const _ModeCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
    required this.isUrdu,
  });

  @override
  Widget build(BuildContext context) {
    final urduStyle =
        TextStyle(fontFamily: isUrdu ? 'NotoNastaliqUrdu' : null);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.teal.shade900.withOpacity(0.05),
            blurRadius: 15,
            spreadRadius: 1,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Card(
        elevation: 0,
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: Colors.teal.shade50,
            width: 1,
          ),
        ),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 16,
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF006064).withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    size: 28,
                    color: const Color(0xFF006064),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: urduStyle.copyWith(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        subtitle,
                        style: urduStyle.copyWith(
                          fontSize: 12,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  isUrdu
                      ? Icons.arrow_back_ios_new_rounded
                      : Icons.arrow_forward_ios_rounded,
                  size: 16,
                  color: Colors.teal.shade400,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}